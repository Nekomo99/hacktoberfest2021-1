# SPELL CHECKER

## Problem statement:-
To To Design and Implement a Spell Checker in English

## Solution:-
- We used the method of edit distance for calculating the distance between the query and individual words.
- To rank the results, we used the Jaccard coefficient. 
- We have also used the nltk module to increase the efficiency of our code. 
- For the word list, we have used The Online Plain Text English Dictionary.

## Group Members:-
- Anwesh Nayak :- B218005
- Arijit Parida :- B218006
- Arun Kumar:- B218007
- Ashish Malik:- B218008

> Note:- This project was an assignment for the course of Web Search Mining.  
